import random
import os

CURRENT_PATH = (os.path.dirname(__file__))

with open(CURRENT_PATH + "/cechy_polskie.txt", "r") as file:
    cechy_wszystkie = file.readlines()
    cechy = tuple(
        cecha.strip() for cecha in random.choices(cechy_wszystkie, k=100))
    del cechy_wszystkie

with open(CURRENT_PATH + "/gat_1.txt", "r") as file:
    nazwy_wszystkie = file.readlines()
    nazwy1 = tuple(
        nazwa.strip() for nazwa in random.choices(nazwy_wszystkie, k=100))
    del nazwy_wszystkie

with open(CURRENT_PATH + "/gat_2.txt", "r") as file:
    nazwy_wszystkie = file.readlines()
    nazwy2 = tuple(
        nazwa.strip() for nazwa in random.choices(nazwy_wszystkie, k=100))
    del nazwy_wszystkie

class Individual:
    def __init__(self):
        self.name = f"{random.choice(nazwy1).capitalize()} {random.choice(nazwy2)}"
        self.genome = {key: value for key, value in 
                       zip(
                           random.choices(cechy, k=9), 
                           (random.random() for i in range(9)))}

for i in range(10):
    gatunek = Individual()
    print(gatunek.name)
    for gene in gatunek.genome.keys():
        val = round(gatunek.genome[gene], 3)
        if val <= 0.5:
            if val <= 0.25:
                umiej = "licha"
            else:
                umiej = "pospolita"
        else:
            if val <= 0.75:
                umiej = "solidna"
            else:
                umiej = "wybitna"

        print(f"- {umiej} : {gene}")
    print()
